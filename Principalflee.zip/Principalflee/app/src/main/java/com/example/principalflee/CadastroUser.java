package com.example.principalflee;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CadastroUser extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_user);
    }
}
