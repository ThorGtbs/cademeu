package com.example.principalflee;

public class EmailSenhaUser {

   private String senha;
   private String email;

   public  EmailSenhaUser(){

   }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
